import { Controller, Get, Post, Put, Patch, Delete, Body, Param, ParseUUIDPipe, Query, UseGuards, Res, Req, HttpStatus, ForbiddenException } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { ChannelsService } from './channels.service';
import { GeoBlockService } from '../geo-block/geo-block.service';
import { CreateChannelDto } from './dto/create-channel.dto';
import { BulkImportChannelsDto, ParsePlaylistDto } from './dto/bulk-import-channel.dto';
import { UpdateOverridesDto } from './dto/update-overrides.dto';
import { AddServerDto } from './dto/add-server.dto';
import { UpdateServerDto } from './dto/update-server.dto';
import { ReorderServersDto } from './dto/reorder-servers.dto';
import { Throttle } from '@nestjs/throttler';
import { PaginationDto } from '../common/dto/pagination.dto';
import { ChannelQueryDto } from './dto/channel-query.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { OptionalJwtAuthGuard } from '../common/guards/optional-jwt-auth.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import type { AuthenticatedUser } from '../common/interfaces';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Public } from '../common/decorators/public.decorator';
import { SettingsService } from '../settings/settings.service';
import { HealthOverride } from '@prisma/client';

@ApiTags('Channels')
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'channels', version: '1' })
export class ChannelsController {
  constructor(
    private channelsService: ChannelsService,
    private geoBlockService: GeoBlockService,
    private settingsService: SettingsService,
  ) {}

  private async enforceGeoBlock(req: Request): Promise<void> {
    const country = (req.headers['cf-ipcountry'] ?? req.headers['x-country']) as string | undefined;
    if (!country) return;
    const { isBlocked } = await this.geoBlockService.isBlocked(country);
    if (isBlocked) throw new ForbiddenException(`Content is not available in your region (${country})`);
  }

  private async getHealthMode(): Promise<string> {
    try {
      const s = await this.settingsService.get('health_check_mode');
      return (s?.value as string) || 'SERVER';
    } catch { return 'SERVER'; }
  }

  @Public()
  @Get()
  @ApiOperation({ summary: 'Get all channels' })
  async findAll(@Query() query: ChannelQueryDto, @Req() req: Request) {
    await this.enforceGeoBlock(req);
    return this.channelsService.findAll(query as any);
  }

  @Public()
  @Get('featured')
  @ApiOperation({ summary: 'Get featured channels' })
  getFeatured() { return this.channelsService.getFeatured(); }

  @Public()
  @Get('trending')
  @ApiOperation({ summary: 'Get trending channels' })
  getTrending() { return this.channelsService.getTrending(); }

  @Get('export')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Export channels as JSON, CSV, or M3U' })
  @ApiQuery({ name: 'format', required: false, enum: ['json', 'csv', 'm3u'] })
  async exportChannels(@Query('format') format: 'json' | 'csv' | 'm3u' = 'json', @Res() res: Response) {
    const content = await this.channelsService.exportChannels(format);
    const mimeMap = { json: 'application/json', csv: 'text/csv', m3u: 'application/x-mpegurl' };
    const extMap  = { json: 'json', csv: 'csv', m3u: 'm3u' };
    res.setHeader('Content-Type', mimeMap[format]);
    res.setHeader('Content-Disposition', `attachment; filename="channels.${extMap[format]}"`);
    return res.status(HttpStatus.OK).send(content);
  }

  @Post()
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Create a channel' })
  create(@Body() dto: CreateChannelDto) { return this.channelsService.create(dto); }

  @Post('bulk')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Bulk import channels' })
  bulkImport(@Body() dto: BulkImportChannelsDto) { return this.channelsService.bulkImport(dto); }

  @Post('bulk-import')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Bulk import channels (alias for /bulk)' })
  bulkImportAlias(@Body() dto: BulkImportChannelsDto) { return this.channelsService.bulkImport(dto); }

  @Get('preview-duplicates')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin')
  @ApiOperation({ summary: 'Preview duplicate channel groups without merging' })
  previewDuplicates() { return this.channelsService.previewDuplicates(); }

  @Post('merge-duplicates')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin')
  @ApiOperation({ summary: 'Merge duplicate channels by normalized name (optionally exclude groups)' })
  mergeDuplicates(@Body('excludedNormalizedNames') excluded?: string[]) {
    return this.channelsService.mergeDuplicates(excluded ?? []);
  }

  @Post('cleanup-bad-names')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin')
  @ApiOperation({ summary: 'Soft-delete channels with image-URL-style names from broken M3U parsing' })
  cleanupBadNames() { return this.channelsService.cleanupBadChannelNames(); }

  @Post('fix-quality-names')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin')
  @ApiOperation({ summary: 'Strip quality/variant suffixes (HD, 720p, (1), (a) etc.) from channel names and merge duplicates' })
  fixQualityNames() { return this.channelsService.fixQualityNames(); }

  @Post('parse-playlist')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Fetch and parse a remote M3U/JSON/CSV playlist URL' })
  parsePlaylist(@Body() dto: ParsePlaylistDto) { return this.channelsService.parsePlaylistUrl(dto.url); }

  @Public()
  @Get(':id')
  @ApiOperation({ summary: 'Get channel by ID or slug (public — credentials stripped)' })
  async findOne(@Param('id', ParseUUIDPipe) id: string, @Req() req: Request) {
    await this.enforceGeoBlock(req);
    return this.channelsService.findOne(id);
  }

  @Get(':id/sources')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor', 'moderator', 'user')
  @ApiOperation({ summary: 'Get channel with full server credentials for authenticated playback (mobile)' })
  async findOneWithSources(@Param('id', ParseUUIDPipe) id: string, @Req() req: Request) {
    await this.enforceGeoBlock(req);
    return this.channelsService.findOneWithSources(id);
  }

  @Get(':id/details')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Get channel by ID or slug with full server credentials (admin only)' })
  async findOneAdmin(@Param('id', ParseUUIDPipe) id: string) {
    return this.channelsService.findOneAdmin(id);
  }

  @Public()
  @UseGuards(OptionalJwtAuthGuard)
  @Get(':id/stream')
  @ApiOperation({ summary: 'Get stream URL for a channel (premium channels require an authenticated premium subscription)' })
  async getStream(@Param('id', ParseUUIDPipe) id: string, @Req() req: Request, @CurrentUser() user: AuthenticatedUser | null) {
    await this.enforceGeoBlock(req);
    return this.channelsService.getStreamUrl(id, user ?? null);
  }

  @Public()
  @Post(':id/view')
  @Throttle({ default: { limit: 1, ttl: 300000 } })
  @ApiOperation({ summary: 'Increment view count' })
  incrementView(@Param('id', ParseUUIDPipe) id: string) { return this.channelsService.incrementViewCount(id); }

  @Get(':id/health')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'moderator')
  @ApiOperation({ summary: 'Get full health stats for a channel' })
  async getHealth(@Param('id', ParseUUIDPipe) id: string) {
    const mode = await this.getHealthMode();
    return this.channelsService.getChannelHealthStats(id, mode);
  }

  @Put(':id/health-override')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin')
  @ApiOperation({ summary: 'Set manual health override for a channel' })
  setOverride(@Param('id', ParseUUIDPipe) id: string, @Body('override') override: HealthOverride) {
    return this.channelsService.setHealthOverride(id, override);
  }

  @Put(':id')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Update a channel' })
  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: Partial<CreateChannelDto>) {
    return this.channelsService.update(id, dto);
  }

  @Delete('delete-all')
  @ApiBearerAuth()
  @Roles('super_admin')
  @ApiOperation({ summary: 'Soft-delete ALL channels and servers in one shot (super_admin only)' })
  deleteAll() { return this.channelsService.deleteAll(); }

  @Delete(':id')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin')
  @ApiOperation({ summary: 'Delete a channel' })
  remove(@Param('id', ParseUUIDPipe) id: string) { return this.channelsService.remove(id); }

  // ── Admin overrides ─────────────────────────────────────────────────────────

  @Patch(':id/overrides')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Set admin overrides for a GitHub-synced channel' })
  updateOverrides(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateOverridesDto) {
    return this.channelsService.updateOverrides(id, dto);
  }

  @Delete(':id/overrides/:field')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Reset a specific admin override back to GitHub value' })
  resetOverride(@Param('id', ParseUUIDPipe) id: string, @Param('field') field: string) {
    return this.channelsService.resetOverride(id, field);
  }

  // ── Server management ────────────────────────────────────────────────────────

  @Get(':id/servers')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor', 'moderator')
  @ApiOperation({ summary: 'Get all servers for a channel (admin — includes disabled)' })
  getServers(@Param('id', ParseUUIDPipe) id: string) {
    return this.channelsService.getServers(id);
  }

  @Post(':id/servers')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Add an admin-managed server to a channel' })
  addServer(@Param('id', ParseUUIDPipe) id: string, @Body() dto: AddServerDto) {
    return this.channelsService.addServer(id, dto);
  }

  @Put(':id/servers')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Bulk-reorder servers (set priorities)' })
  reorderServers(@Param('id', ParseUUIDPipe) id: string, @Body() body: ReorderServersDto) {
    return this.channelsService.reorderServers(id, body.servers);
  }

  @Patch(':id/servers/:serverId')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Update a single server (enabled, link, headers)' })
  updateServer(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('serverId') serverId: string,
    @Body() dto: UpdateServerDto,
  ) {
    return this.channelsService.updateServer(id, serverId, dto);
  }

  @Post(':id/servers/:serverId/test')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor', 'moderator')
  @ApiOperation({ summary: 'Test server reachability from the API host' })
  testServer(@Param('id', ParseUUIDPipe) id: string, @Param('serverId') serverId: string) {
    return this.channelsService.testServer(id, serverId);
  }

  @Delete(':id/servers/:serverId')
  @ApiBearerAuth()
  @Roles('super_admin', 'admin', 'editor')
  @ApiOperation({ summary: 'Soft-delete a server from a channel' })
  deleteServer(@Param('id', ParseUUIDPipe) id: string, @Param('serverId') serverId: string) {
    return this.channelsService.deleteServer(id, serverId);
  }
}
